
#import <Cocoa/Cocoa.h>




@interface VVSpriteControlCell : NSActionCell {

}

@end
